This directory is empty buit it's used when packaging the Python library.
the files in ../../Scripts will be copied inside.
